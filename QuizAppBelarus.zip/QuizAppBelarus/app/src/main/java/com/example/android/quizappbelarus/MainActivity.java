package com.example.android.quizappbelarus;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


/**
 * This app displays a set of questions to test user's knowledge about Belarus.
 */
public class MainActivity extends AppCompatActivity {

    int totalscore = 0;
    int scorequiz1 = 0;
    int scorequiz2 = 0;
    int scorequiz3 = 0;
    int scorequiz4 = 0;
    int exiterr = 0;
    String errmessage = "";
    String finalmessage = "";
    String answermessage = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * This method is called when the SUBMIT button is clicked.
     * It checks each quiz and follows up with error checking.
     * If no errors calculate scores that users answered correctly
     * Then print the total score in textview and print answer key in toast
     */
    public void submitAnswer(View view) {

        checkQuiz1();
        if (exiterr > 0) {
            return;
        }
        checkQuiz2();
        if (exiterr > 0) {
            return;
        }
        checkQuiz3();
        if (exiterr > 0) {
            return;
        }
        checkQuiz4();
        if (exiterr > 0) {
            return;
        }

        totalscore = scorequiz1 + scorequiz2 + scorequiz3 + scorequiz4;
        TextView textViewFinal = findViewById(R.id.final_text_view);

        if (totalscore >= 75) {
            finalmessage = "Awesome! Your total score is " + totalscore + " out of 100. You do know Belarus!";
        } else {
            finalmessage = "Your total score is " + totalscore + " out of 100. Thanks for your participation!";
        }

        textViewFinal.setTextColor(getResources().getColor(android.R.color.tab_indicator_text));
        textViewFinal.setTypeface(null, Typeface.BOLD);
        textViewFinal.setText(finalmessage);

        printAnswer();
    }

    /**
     * This method print answer key in toast
     */
    private void printAnswer(){
        answermessage = "Please check out the answer key below" + "\n";
        answermessage = answermessage + "Quiz 1: Minsk" + "\n";
        answermessage = answermessage + "Quiz 2: Russian" + "\n";
        answermessage = answermessage + "Quiz 3: Slovakia and Estonia" + "\n";
        answermessage = answermessage + "Quiz 4: 10 million" + "\n";

        Toast toast = Toast.makeText(this, answermessage, Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.show();
    }

    /**
     * This method checks user's answer on Quiz 1 when user click SUBMIT button
     * If no answer provided throws an error and print at bottom in a textview
     */
    private void checkQuiz1() {
        exiterr = 0;
        TextView textViewErrQuiz1 = findViewById(R.id.final_text_view);
        textViewErrQuiz1.setText("");
        RadioGroup radioGroupQuiz1 = findViewById(R.id.radioGroupQuiz1);
        if (radioGroupQuiz1.getCheckedRadioButtonId() == -1) {
            errmessage = "Error - please select an answer for Quiz 1 ..." + "\n";
            textViewErrQuiz1.setTextColor(Color.RED);
            textViewErrQuiz1.setText(errmessage);
            exiterr = 1;
        } else {
            int radioIdQuiz1 = radioGroupQuiz1.getCheckedRadioButtonId();
            RadioButton radioButtonQuiz1 = findViewById(radioIdQuiz1);
            String quiz1AnswerKey = (String) radioButtonQuiz1.getText();

            if (quiz1AnswerKey.equals("Minsk")) {
                scorequiz1 = 25;
            } else {
                scorequiz1 = 0;
            }
        }
    }
    /**
     * This method checks user's answer on Quiz 4 when user click SUBMIT button
     * If no answer provided throws an error and print at bottom in a textview
     */
    private void checkQuiz4() {
        exiterr = 0;
        TextView textViewErrQuiz4 = findViewById(R.id.final_text_view);
        textViewErrQuiz4.setText("");
        RadioGroup radioGroupQuiz4 = findViewById(R.id.radioGroupQuiz4);
        if (radioGroupQuiz4.getCheckedRadioButtonId() == -1) {
            errmessage = "Error - please select an answer for Quiz 4 ..." + "\n";
            textViewErrQuiz4.setTextColor(Color.RED);
            textViewErrQuiz4.setText(errmessage);
            exiterr = 1;
        } else {
            int radioIdQuiz4 = radioGroupQuiz4.getCheckedRadioButtonId();
            RadioButton radioButtonQuiz4 = findViewById(radioIdQuiz4);
            String quiz4AnswerKey = (String) radioButtonQuiz4.getText();

            if (quiz4AnswerKey.equals("10 million")) {
                scorequiz4 = 25;
            } else {
                scorequiz4 = 0;
            }
        }
    }

    /**
     * This method checks user's answer on Quiz 3 when user click SUBMIT button
     * If no answer provided throws an error and print at bottom in a textview
     */
    private void checkQuiz3() {
        exiterr = 0;
        TextView textViewErrQuiz3 = findViewById(R.id.final_text_view);
        textViewErrQuiz3.setText("");

        CheckBox checkQuiz3A = findViewById(R.id.checkBoxQuiz3A);
        CheckBox checkQuiz3B = findViewById(R.id.checkBoxQuiz3B);
        CheckBox checkQuiz3C = findViewById(R.id.checkBoxQuiz3C);
        CheckBox checkQuiz3D = findViewById(R.id.checkBoxQuiz3D);
        boolean isCheckedQuiz3A = checkQuiz3A.isChecked();
        boolean isCheckedQuiz3B = checkQuiz3B.isChecked();
        boolean isCheckedQuiz3C = checkQuiz3C.isChecked();
        boolean isCheckedQuiz3D = checkQuiz3D.isChecked();

        if ((!isCheckedQuiz3A) && (!isCheckedQuiz3B) && (!isCheckedQuiz3C) && (!isCheckedQuiz3D)) {
            errmessage = "Error - please check at least one answer for Quiz 3 ..." + "\n";
            textViewErrQuiz3.setTextColor(Color.RED);
            textViewErrQuiz3.setText(errmessage);
            exiterr = 1;
        } else if ((isCheckedQuiz3B) && (isCheckedQuiz3C) && (!isCheckedQuiz3A) && (!isCheckedQuiz3D)) {
            scorequiz3 = 25;
        } else {
            scorequiz3 = 0;
        }
    }

    /**
     * This method checks user's answer on Quiz 2 when user click SUBMIT button
     * If no answer provided or provided not following instruction then throw an error and print at bottom in a textview
     */
    private void checkQuiz2() {
        exiterr = 0;
        TextView textViewErrQuiz2 = findViewById(R.id.final_text_view);
        textViewErrQuiz2.setText("");

        EditText editTextQuiz2 = findViewById(R.id.editTxtQuiz2Answer);
        String quiz2answer = editTextQuiz2.getText().toString();

        if (quiz2answer.equalsIgnoreCase("Russian")){
            scorequiz2 = 25;
        } else if ((quiz2answer.equalsIgnoreCase("Belarusian")) ||
                (quiz2answer.equalsIgnoreCase("Polish")) ||
                (quiz2answer.equalsIgnoreCase("Ukrainian"))) {
            scorequiz2 = 0;
        } else {
            errmessage = "Error - please type in your chosen language and check spelling following instruction for Quiz 2 ..." + "\n";
            textViewErrQuiz2.setTextColor(Color.RED);
            textViewErrQuiz2.setText(errmessage);
            exiterr = 1;
        }
    }

}