package com.example.android.soccerscorekeeper;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int scoreTeamA = 0;
    int scoreTeamB = 0;
    int numRedCardA = 0;
    int numRedCardB = 0;
    int numYellowCardA = 0;
    int numYellowCardB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
        displayRedForTeamA(numRedCardA);
        displayRedForTeamB(numRedCardB);
        displayYellowForTeamA(numYellowCardA);
        displayYellowForTeamB(numYellowCardB);
    }

    public void displayForTeamA(int score) {
        TextView scoreview = (TextView) findViewById(R.id.team_a_score);
        scoreview.setText(String.valueOf(score));
    }

    public void displayForTeamB(int scoreB) {
        TextView scoreviewb = (TextView) findViewById(R.id.team_b_score);
        scoreviewb.setText(String.valueOf(scoreB));
    }

    public void displayRedForTeamA(int scoreR) {
        TextView scoreviewR = (TextView) findViewById(R.id.team_a_redcards);
        scoreviewR.setText(String.valueOf(scoreR));
    }

    public void displayRedForTeamB(int scoreRB) {
        TextView scoreviewRb = (TextView) findViewById(R.id.team_b_redcards);
        scoreviewRb.setText(String.valueOf(scoreRB));
    }

    public void displayYellowForTeamA(int scoreY) {
        TextView scoreviewY = (TextView) findViewById(R.id.team_a_yellowcards);
        scoreviewY.setText(String.valueOf(scoreY));
    }

    public void displayYellowForTeamB(int scoreYB) {
        TextView scoreviewYb = (TextView) findViewById(R.id.team_b_yellowcards);
        scoreviewYb.setText(String.valueOf(scoreYB));
    }

    public void addGoals(View view) {
        scoreTeamA = scoreTeamA + 1;
        displayForTeamA(scoreTeamA);
    }

    public void addGoalsB(View view) {
        scoreTeamB = scoreTeamB + 1;
        displayForTeamB(scoreTeamB);
    }

    public void addRedCards(View view) {
        numRedCardA = numRedCardA + 1;
        displayRedForTeamA(numRedCardA);
    }

    public void addRedCardsB(View view) {
        numRedCardB = numRedCardB + 1;
        displayRedForTeamB(numRedCardB);
    }

    public void addYellowCards(View view) {
        numYellowCardA = numYellowCardA + 1;
        displayYellowForTeamA(numYellowCardA);
    }

    public void addYellowCardsB(View view) {
        numYellowCardB = numYellowCardB + 1;
        displayYellowForTeamB(numYellowCardB);
    }

    public void reset(View view) {
        scoreTeamA = 0;
        scoreTeamB = 0;
        numRedCardA = 0;
        numRedCardB = 0;
        numYellowCardA = 0;
        numYellowCardB = 0;
        displayForTeamA(scoreTeamA);
        displayForTeamB(scoreTeamB);
        displayRedForTeamA(numRedCardA);
        displayRedForTeamB(numRedCardB);
        displayYellowForTeamA(numYellowCardA);
        displayYellowForTeamB(numYellowCardB);
    }

}
